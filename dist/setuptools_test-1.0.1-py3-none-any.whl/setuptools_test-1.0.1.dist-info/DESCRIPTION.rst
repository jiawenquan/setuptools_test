setuptools 简单的测试   这里是详细描述


